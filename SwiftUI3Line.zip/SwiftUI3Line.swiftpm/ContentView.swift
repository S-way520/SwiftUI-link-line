import SwiftUI

struct ContentView: View {
    @State private var startPoint: CGPoint = CGPoint(x: 100, y: 100)
    @State private var endPoint: CGPoint = CGPoint(x: 300, y: 500)
    
    var body: some View {
        ZStack {
            Path { (path) in
                path.move(to: startPoint)
                
                path.addQuadCurve(to: CGPoint(x: (endPoint.x + startPoint.x) / 2, y: (endPoint.y + startPoint.y) / 2), control: CGPoint(x: (endPoint.x + startPoint.x) / 2, y: (2 * startPoint.y) / 2))
                
                path.addQuadCurve(to: endPoint, control: CGPoint(x: (endPoint.x + startPoint.x) / 2, y: (2 * endPoint.y) / 2))
                
            }
            .strokedPath(StrokeStyle(lineWidth: 5, lineCap: .square, lineJoin: .round))
            .foregroundColor(.green)
            
            //Circle 1
            
            TextEditor(text: .constant("Pla"))
                .frame(width: 100, height: 40)
                .border(Color.black)
                .foregroundColor(.blue)
                .position(x: startPoint.x-100/2-10, y: startPoint.y)
            Circle()
                .frame(width: 20, height: 20)
                .position(startPoint)
                .foregroundColor(.blue)
                .gesture(DragGesture()
                    .onChanged { (value) in
                        self.startPoint = CGPoint(x: value.location.x, y: value.location.y)
                    })
            
            //Circle 2
            Circle()
                .frame(width: 20, height: 20)
                .position(endPoint)
                .foregroundColor(.red)
                .gesture(DragGesture()
                    .onChanged { (value) in
                        self.endPoint = CGPoint(x: value.location.x, y: value.location.y)
                    })
            Color.clear
        }
    }
}

